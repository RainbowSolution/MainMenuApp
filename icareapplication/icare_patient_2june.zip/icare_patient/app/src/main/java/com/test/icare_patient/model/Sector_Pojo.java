package com.test.icare_patient.model;

import java.util.ArrayList;

public class Sector_Pojo {
//
//@SerializedName("status")
//@Expose
//private Boolean status;
//@SerializedName("message")
//@Expose
//private String message;
//@SerializedName("data")
//@Expose
//private ArrayList<Sector_info> data = null;
//
//public Boolean getStatus() {
//return status;
//}
//
//public void setStatus(Boolean status) {
//this.status = status;
//}
//
//public String getMessage() {
//return message;
//}
//
//public void setMessage(String message) {
//this.message = message;
//}
//
//public ArrayList<Sector_info> getData() {
//return data;
//}
//
//public void setData(ArrayList<Sector_info> data) {
//this.data = data;
//}

}