package com.test.icare_patient;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.test.icare_patient.create_account.Create_Account_Activity;
import com.test.icare_patient.home_pkg.HomeActivity;

public class Patient_Login_Activity extends AppCompatActivity implements View.OnClickListener {
 ImageView id_back12; TextView iv_forgetpass,signup;
 Button btn_login; View id_toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initView();
    }

    private void initView() {
        id_toolbar = findViewById(R.id.id_toolbar);
        id_back12 = id_toolbar.findViewById(R.id.id_back);
        btn_login = findViewById(R.id.btn_login);
        iv_forgetpass = findViewById(R.id.iv_forgetpass);
        signup = findViewById(R.id.signup);

        id_back12.setOnClickListener(this);
        btn_login.setOnClickListener(this);
        iv_forgetpass.setOnClickListener(this);
        signup.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.signup:
                startActivity(new Intent(Patient_Login_Activity.this, Create_Account_Activity.class));
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
                break;

            case R.id.id_back:
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
                break;

            case R.id.btn_login:
                startActivity(new Intent(Patient_Login_Activity.this, HomeActivity.class));
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
                finish();
                break;

            case R.id.iv_forgetpass:
                startActivity(new Intent(Patient_Login_Activity.this, Forget_Activity.class));
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
                break;
        }
    }
}
