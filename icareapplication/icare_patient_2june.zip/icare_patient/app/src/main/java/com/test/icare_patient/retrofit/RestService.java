package com.test.icare_patient.retrofit;

public interface RestService {
//    @POST("doctor_registration")
//    Call<JsonObject> doctor_reg(@Body UserInfo jsonObject);
//
//    @POST("Patientlogin")
//    Call<JsonObject> doctor_login(@Body UserInfo jsonObject);
//
//    @GET("get_department")
//    Call<Sector_Pojo> getSectorDetail();

}
