package com.fivido.sectionedexpandablegridlayout.apiPkg;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class RetrofitClient {

    public static final String PROFILE = "http://15.206.103.57/GrowKart/api/uploads/";
    public static final String BASE_URL = "http://15.206.103.57/GrowKart/api/index.php/";
    public static final String PRODUCT_IMAGE_URL = "http://15.206.103.57/GrowKart/uploads/products/";
    public static final String CATEGORY_IMAGE_URL = "http://15.206.103.57/GrowKart/uploads/category/";
    public static final String SUB_CATEGORY_IMAGE_URL = "http://15.206.103.57/GrowKart/uploads/subcat/";
    public static final String BANNER_URL = "http://15.206.103.57/GrowKart/uploads/sliders/";
    public static final String OFFER_BANNER_URL = "http://15.206.103.57/GrowKart/uploads/sliders/";

    private static OkHttpClient client;
    private static Retrofit retrofit = null;

    public static Retrofit getClient() {

        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
        clientBuilder.connectTimeout(5, TimeUnit.MINUTES);
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(clientBuilder.build())
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit;
    }

}