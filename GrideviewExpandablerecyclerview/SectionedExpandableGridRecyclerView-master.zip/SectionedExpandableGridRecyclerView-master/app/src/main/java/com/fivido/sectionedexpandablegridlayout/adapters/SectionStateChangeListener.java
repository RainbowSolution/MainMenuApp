package com.fivido.sectionedexpandablegridlayout.adapters;

/**
 * Created by bpncool on 2/24/2016.
 */

import com.fivido.sectionedexpandablegridlayout.Modalpkg.CategoryMain;

/**
 * interface to listen changes in state of sections
 */
public interface SectionStateChangeListener {
    void onSectionStateChanged(CategoryMain section, boolean isOpen);
}