package com.fivido.sectionedexpandablegridlayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.fivido.sectionedexpandablegridlayout.Modalpkg.Allcategory;
import com.fivido.sectionedexpandablegridlayout.Modalpkg.CategoryMain;

import com.fivido.sectionedexpandablegridlayout.Modalpkg.subCategoryPkg.Datum;
import com.fivido.sectionedexpandablegridlayout.Modalpkg.subCategoryPkg.SubCategoryPozo;
import com.fivido.sectionedexpandablegridlayout.adapters.ItemClickListener;
import com.fivido.sectionedexpandablegridlayout.adapters.Section;
import com.fivido.sectionedexpandablegridlayout.adapters.SectionedExpandableLayoutHelper;
import com.fivido.sectionedexpandablegridlayout.apiPkg.ApiServices;
import com.fivido.sectionedexpandablegridlayout.apiPkg.RetrofitClient;
import com.fivido.sectionedexpandablegridlayout.models.Item;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity implements ItemClickListener {

    RecyclerView mRecyclerView;
    private ArrayList<CategoryMain> categoryMains;
    private ArrayList<Datum> subcategoryMains;
    private ApiServices apiServices;
    SectionedExpandableLayoutHelper sectionedExpandableLayoutHelper;
    private LinkedHashMap<CategoryMain, ArrayList<Datum>> stringParentCategorySectionHashMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        apiServices = RetrofitClient.getClient().create(ApiServices.class);
        //setting the recycler view
        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
         sectionedExpandableLayoutHelper = new SectionedExpandableLayoutHelper(this,
                mRecyclerView, this, 3);
        categoryMains = new ArrayList<>();
        subcategoryMains = new ArrayList<>();
        stringParentCategorySectionHashMap = new LinkedHashMap();
        //random data
     /*   ArrayList<Item> arrayList = new ArrayList<>();
        arrayList.add(new Item("iPhone", 0));
        arrayList.add(new Item("iPad", 1));
        arrayList.add(new Item("iPod", 2));
        arrayList.add(new Item("iMac", 3));
        arrayList = new ArrayList<>();
        arrayList.add(new Item("LG", 0));
        arrayList.add(new Item("Apple", 1));
        arrayList.add(new Item("Samsung", 2));
        arrayList.add(new Item("Motorola", 3));
        arrayList.add(new Item("Sony", 4));
        arrayList.add(new Item("Nokia", 5));
        sectionedExpandableLayoutHelper.addSection("Companies", arrayList);
        arrayList = new ArrayList<>();
        arrayList.add(new Item("Chocolate", 0));
        arrayList.add(new Item("Strawberry", 1));
        arrayList.add(new Item("Vanilla", 2));
        arrayList.add(new Item("Butterscotch", 3));
        arrayList.add(new Item("Grape", 4));
        sectionedExpandableLayoutHelper.addSection("Ice cream", arrayList);

        sectionedExpandableLayoutHelper.notifyDataSetChanged();

        //checking if adding single item works
        sectionedExpandableLayoutHelper.addItem("Ice cream", new Item("Tutti frutti",5));
        sectionedExpandableLayoutHelper.notifyDataSetChanged();*/
        getallcategory();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void itemClicked(Datum item) {

    }

    @Override
    public void itemClicked(CategoryMain section) {
        Toast.makeText(this, "Section: " + section.getSubcat_name() + " clicked", Toast.LENGTH_SHORT).show();
    }

    private void getallcategory() {
//        pbHome.setVisibility(View.VISIBLE);
        apiServices.getAllCategory().enqueue(new Callback<Allcategory>() {
            @Override
            public void onResponse(Call<Allcategory> call, Response<Allcategory> response) {
                if (response.isSuccessful()) {
//                    pbHome.setVisibility(View.GONE);
                    Allcategory productlist = response.body();
                    categoryMains = productlist.getData();
                    for(int i=0; i<categoryMains.size(); i++){
                        getProductdetails(categoryMains.get(i),categoryMains.get(i).getId());
                    }
                    sectionedExpandableLayoutHelper.addParentCategory(stringParentCategorySectionHashMap);
                    sectionedExpandableLayoutHelper.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<Allcategory> call, Throwable t) {
//                pbHome.setVisibility(View.GONE);
            }
        });
    }

    private void getProductdetails(final CategoryMain categoryMain, final String id) {
        apiServices.getSubategory(id).enqueue(new Callback<SubCategoryPozo>() {
            @Override
            public void onResponse(Call<SubCategoryPozo> call, Response<SubCategoryPozo> response) {
                if (response.isSuccessful()) {
                    SubCategoryPozo productlist = response.body();
                    if (response.isSuccessful()) {
                        subcategoryMains = productlist.getData();
                        stringParentCategorySectionHashMap.put(categoryMain, subcategoryMains);
                        sectionedExpandableLayoutHelper.addParentCategory(stringParentCategorySectionHashMap);
                    }
                    sectionedExpandableLayoutHelper.notifyDataSetChanged();
                } else {
                    if (response.code() == 400) {
                        if (!false) {
                            JSONObject jsonObject = null;
                            try {
                                jsonObject = new JSONObject(response.errorBody().string());
//                                pbLoginId.setVisibility(View.GONE);
//                                tvProduct.setVisibility(View.VISIBLE);
                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<SubCategoryPozo> call, Throwable t) {
//                pbLoginId.setVisibility(View.GONE);
//                tvProduct.setVisibility(View.VISIBLE);
            }
        });
    }

}
