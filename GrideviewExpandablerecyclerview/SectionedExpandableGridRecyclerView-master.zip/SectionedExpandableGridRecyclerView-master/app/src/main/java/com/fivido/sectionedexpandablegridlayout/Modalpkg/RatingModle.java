package com.fivido.sectionedexpandablegridlayout.Modalpkg;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RatingModle {
    @SerializedName("status")
    @Expose
    private Boolean status;
    @SerializedName("message")
    @Expose
    private String message;

    public RatingModle() {
    }

    public RatingModle(Boolean status, String message) {
        this.status = status;
        this.message = message;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
