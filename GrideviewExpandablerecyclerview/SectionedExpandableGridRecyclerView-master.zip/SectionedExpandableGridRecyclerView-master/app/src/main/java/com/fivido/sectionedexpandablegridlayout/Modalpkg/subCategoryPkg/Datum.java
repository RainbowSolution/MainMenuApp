
package com.fivido.sectionedexpandablegridlayout.Modalpkg.subCategoryPkg;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Datum {

    @SerializedName("sub_cat_id")
    @Expose
    private String subCatId;
    @SerializedName("cat_id")
    @Expose
    private String catId;
    @SerializedName("subcat_name")
    @Expose
    private String subcatName;
    @SerializedName("subcat_img")
    @Expose
    private String subcatImg;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("created_at")
    @Expose
    private String createdAt;

    public Datum(String subCatId, String catId, String subcatName, String subcatImg, String status, String createdAt) {
        this.subCatId = subCatId;
        this.catId = catId;
        this.subcatName = subcatName;
        this.subcatImg = subcatImg;
        this.status = status;
        this.createdAt = createdAt;
    }

    public String getSubCatId() {
        return subCatId;
    }

    public void setSubCatId(String subCatId) {
        this.subCatId = subCatId;
    }

    public String getCatId() {
        return catId;
    }

    public void setCatId(String catId) {
        this.catId = catId;
    }

    public String getSubcatName() {
        return subcatName;
    }

    public void setSubcatName(String subcatName) {
        this.subcatName = subcatName;
    }

    public String getSubcatImg() {
        return subcatImg;
    }

    public void setSubcatImg(String subcatImg) {
        this.subcatImg = subcatImg;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

}
